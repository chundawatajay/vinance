<?php

namespace App\Models\P2P;

use Illuminate\Database\Eloquent\Model;

class TradeFeedBack extends Model
{
    protected $table = "p2p_trade_feed_backs";
}
