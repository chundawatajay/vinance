<?php
$pusherAppId       = "1630651";
$pusherAppKey      ="15d782b9814d59f4b88b";
$pusherAppSecret   ="2c9a3c75c1529b527ab7";
$pusherAppCluster  ="ap2";
?>